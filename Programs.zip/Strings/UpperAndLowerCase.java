package Worksheets.Strings;
public class UpperAndLowerCase {
    public static void main(String[] args) {
        System.out.println();
        String word = "WoRd";
        System.out.println(word.toUpperCase());
        System.out.println(word.toLowerCase());
    }
}
