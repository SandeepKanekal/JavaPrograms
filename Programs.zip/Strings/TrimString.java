package Worksheets.Strings;
public class TrimString {
    public static void main(String[] args) {
        String word = "  name  ";
        word = word.trim();
        System.out.println("\n" +word);
    }
}
