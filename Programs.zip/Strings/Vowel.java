package Worksheets.Strings;

public class Vowel {
    public boolean checkIfVowel(char letter) {
        return letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u' || letter == 'A'
                || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U';
    }
}
